<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="hidden index category"></div>

    <!-- Main -->
    <main class="news-gallery container">
        <!-- Classifieds -->
        <div class="classifieds container">
            <h1 id="h1-classifieds"></h1>
            <div class="row clearfix" id="classifieds-gallery">
                <!-- Populated via JS -->
            </div>
        </div> <!-- / .classifieds -->

        <nav class="breadcrumb" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <h1 id="category-name">Todas las Noticias</h1><span class="counter">(<span id="article-count">...</span> artículos)</span>
                </li>
            </ol>
        </nav>

        <div class="articles-featured container">
            <div id="carouselFeatured" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators" id="carousel-indicators">
                </div>
                <div class="carousel-inner rounded-5 shadow" id="carousel-inner">
                    <!-- Populated via JS -->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselFeatured" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Anterior</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselFeatured" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Siguiente</span>
                </button>
            </div>
        </div> <!-- / .articles-featured -->

        <div class="articles-gallery overflow-hidden row g-4 mx-2 mx-lg-0" id="articles-gallery">
            <!-- Populated via JS -->
        </div> <!-- / .custom-grid -->
    </main> <!-- / .news-gallery -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/resources/views/welcome.blade.php ENDPATH**/ ?>