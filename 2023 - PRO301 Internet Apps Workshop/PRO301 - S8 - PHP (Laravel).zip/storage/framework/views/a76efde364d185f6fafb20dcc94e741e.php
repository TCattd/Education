    <!-- Footer -->
    <footer class="container d-flex footer rounded shadow p-4">
        <div class="row align-items-center">
            <div class="col-auto copyright">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(url('/')); ?>/images/elfaro-logo.png" alt="El Faro Logo" width="40" alt='Logo El Faro' />
                </a>
                Copyright © <span id="footer-year"></span> El Faro. Todos los derechos reservados.
            </div>
        </div>
    </footer> <!-- / .footer -->

    <!-- DEBUG: Clear localStorage -->
    <div class="clearLocalStorage text-center">
        <a class="btn btn-danger" id="clearLocalStorage">Borrar DB local (localStorage)</a>
    </div> <!-- / .clearLocalStorage -->
</body>
</html>
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/public/resources/views/layouts/footer.blade.php ENDPATH**/ ?>