<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="hidden contact"></div>

    <!-- Main Article -->
    <main class="main container">
        <nav class="breadcrumb" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <h1>Contacto</h1>
                </li>
            </ol>
        </nav>

        <div class="row">
            <section class="article col-12 card p-5">
                <p>
                    <!-- Site title -->
                    <strong><?php echo e(config('app.name')); ?></strong> es un periódico digital que se enfoca en la actualidad nacional e internacional.
                    Contamos con una amplia cobertura de noticias de deportes, negocios, política y más.
                </p>
                <hr>
                <p>
                    Escríbanos:
                </p>

                <?php if(Session::has('success')): ?>
                <p>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                </p>
                <?php endif; ?>

                <?php if(Session::has('error')): ?>
                <p>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('error')); ?>

                    </div>
                </p>
                <?php endif; ?>

                <form method="POST" id="contact" action="<?php echo e(route('contact.store')); ?>" class="container">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Nombre</label>
                        <div class="col-sm-10">
                            <input class="input form-control" type="text" placeholder="Su nombre y apellido" name="name" value="<?php echo e(old('name')); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <p class="help is-danger"><?php echo e($errors->first('name')); ?></p>
                        <?php endif; ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Asunto</label>
                        <div class="col-sm-10">
                            <input class="input form-control" type="text" placeholder="El asunto de contacto" name="subject" value="<?php echo e(old('subject')); ?>" required>
                        <?php if($errors->has('subject')): ?>
                            <p class="help is-danger"><?php echo e($errors->first('subject')); ?></p>
                        <?php endif; ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Correo</label>
                        <div class="col-sm-10">
                            <input class="input form-control" type="email" placeholder="Su correo electrónico" name="email" value="<?php echo e(old('email')); ?>" required>
                        <?php if($errors->has('email')): ?>
                            <p class="help is-danger"><?php echo e($errors->first('email')); ?></p>
                        <?php endif; ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Mensaje</label>
                        <div class="col-sm-10">
                            <textarea class="textarea form-control js-editor" placeholder="Escriba acá su mensaje" name="message" required><?php echo e(old('message')); ?></textarea>
                        <?php if($errors->has('message')): ?>
                            <p class="help is-danger"><?php echo e($errors->first('message')); ?></p>
                        <?php endif; ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12 send-form-container">
                            <button type="submit" name="send" class="send-form btn btn-primary btn-submit form-control">Enviar Correo</button>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    </main> <!-- / .main -->

<?php echo $__env->make('layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/resources/views/contact.blade.php ENDPATH**/ ?>