<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="hidden classifieds classified"></div>

    <!-- Main -->
    <main class="news-gallery container">
        <nav class="breadcrumb" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <h1 id="">Clasificados</h1><span class="counter">(<span id="article-count">...</span> publicaciones)</span>
                </li>
            </ol>
        </nav>

        <div class="articles-gallery overflow-hidden row g-4 mx-2 mx-lg-0" id="articles-gallery">
            <!-- Populated via JS -->
        </div> <!-- / .custom-grid -->

        <!-- Main Article -->
        <div class="main container article article-container classified-container">
            <div class="row article__content" id="classified-content">
                <!-- Populated via JS -->
            </div> <!-- / #article-content -->
        </div> <!-- / .main -->
    </main> <!-- / .news-gallery -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/public/resources/views/classified.blade.php ENDPATH**/ ?>