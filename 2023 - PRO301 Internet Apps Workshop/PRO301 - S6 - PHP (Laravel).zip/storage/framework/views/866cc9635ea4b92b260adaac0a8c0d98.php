<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="hidden article"></div>

    <!-- Main Article -->
    <main class="main container article article-container">
        <h1 id="category-name"></h1>
        <div class="row article__content" id="article-content">
            <!-- Populated via JS -->
        </div> <!-- / #article-content -->
    </main> <!-- / .main -->

<?php echo $__env->make('layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/resources/views/article.blade.php ENDPATH**/ ?>