<h2>Nuevo mensaje de: <?php echo e($data->name); ?></h2>
<br>

<strong>Detalles del formulario: </strong><br>
<strong>Nombre: </strong><?php echo e($data->name); ?> <br>
<strong>Subject: </strong><?php echo e($data->subject); ?> <br>
<strong>Email: </strong><?php echo e($data->email); ?> <br>
<strong>Mensaje: </strong><?php echo e($data->message); ?> <br><br>

<hr>
<br>

El Faro
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/resources/views/emails/contact.blade.php ENDPATH**/ ?>