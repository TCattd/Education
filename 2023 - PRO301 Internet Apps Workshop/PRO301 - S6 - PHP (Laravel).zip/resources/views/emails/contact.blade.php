<h2>Nuevo mensaje de: {{ $data->name }}</h2>
<br>

<strong>Detalles del formulario: </strong><br>
<strong>Nombre: </strong>{{ $data->name }} <br>
<strong>Subject: </strong>{{ $data->subject }} <br>
<strong>Email: </strong>{{ $data->email }} <br>
<strong>Mensaje: </strong>{{ $data->message }} <br><br>

<hr>
<br>

El Faro
