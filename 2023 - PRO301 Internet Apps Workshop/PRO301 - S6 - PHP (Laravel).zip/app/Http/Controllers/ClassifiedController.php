<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClassifiedController extends Controller
{
    // Attributes
    private $id;
    private $title;
    private $content;
    private $date;
    private $category;
    private $image;
    private $visible;
    private $name;
    private $email;
    private $phone;
    private $price;

    // Constructor
    public function __construct($id, $title, $content, $date, $category, $image, $visible, $name, $email, $phone, $price)
    {
        $this->id         = $id;
        $this->title      = $title;
        $this->content    = $content;
        $this->date       = $date;
        $this->category   = $category;
        $this->image      = $image;
        $this->visible = $visible;
        $this->name       = $name;
        $this->email      = $email;
        $this->phone      = $phone;
        $this->price      = $price;
    }

    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of title
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set the value of title
     */
    public function setTitle($title): self
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get the value of content
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set the value of content
     */
    public function setContent($content): self
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get the value of date
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set the value of date
     */
    public function setDate($date): self
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get the value of category
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * Set the value of category
     */
    public function setCategory($category): self
    {
        $this->category = $category;

        return $this;
    }

    /**
     * Get the value of image
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set the value of image
     */
    public function setImage($image): self
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get the value of visible
     */
    public function getVisibility()
    {
        return $this->visible;
    }

    /**
     * Set the value of visible
     */
    public function setVisibility($visible): self
    {
        $this->visible = $visible;

        return $this;
    }

    /**
     * Get the value of name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set the value of name
     */
    public function setName($name): self
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     */
    public function setEmail($email): self
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of phone
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set the value of phone
     */
    public function setPhone($phone): self
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get the value of price
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set the value of price
     */
    public function setPrice($price): self
    {
        $this->price = $price;

        return $this;
    }

    // Methods
    private function createClassified( $data = [] )
    {
        // Create a new classified
    }

    private function updateClassified( $id = 0, $data = [] )
    {
        // Update a classified
    }

    private function deleteClassified( $id = 0 )
    {
        // Delete a classified
    }

    private function getClassified( $id = 0 )
    {
        // Get a classified
    }

    private function getClassifieds( $category = 'all' )
    {
        // Get all classifieds or by category
    }
}
