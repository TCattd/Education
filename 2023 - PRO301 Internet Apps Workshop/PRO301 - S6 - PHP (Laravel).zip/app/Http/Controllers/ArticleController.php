<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ArticleController extends Controller
{
    // Attributes
    private $id;
    private $title;
    private $content;
    private $excerpt;
    private $author;
    private $date;
    private $category;
    private $source;
    private $featuredImage;
    private $visibile;

    // Constructor
    public function __construct($id, $title, $content, $excerpt, $author, $date, $category, $source, $featuredImage, $visibile)
    {
        $this->id            = $id;
        $this->title         = $title;
        $this->content       = $content;
        $this->excerpt       = $excerpt;
        $this->author        = $author;
        $this->date          = $date;
        $this->category      = $category;
        $this->source        = $source;
        $this->featuredImage = $featuredImage;
        $this->visibile    = $visibile;
    }

    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of title
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set the value of title
     */
    public function setTitle($title): self
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get the value of content
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set the value of content
     */
    public function setContent($content): self
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get the value of excerpt
     */
    public function getExcerpt()
    {
        return $this->excerpt;
    }

    /**
     * Set the value of excerpt
     */
    public function setExcerpt($excerpt): self
    {
        $this->excerpt = $excerpt;

        return $this;
    }

    /**
     * Get the value of author
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * Set the value of author
     */
    public function setAuthor($author): self
    {
        $this->author = $author;

        return $this;
    }

    /**
     * Get the value of date
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set the value of date
     */
    public function setDate($date): self
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get the value of category
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * Set the value of category
     */
    public function setCategory($category): self
    {
        $this->category = $category;

        return $this;
    }

    /**
     * Get the value of source
     */
    public function getSource()
    {
        return $this->source;
    }

    /**
     * Set the value of source
     */
    public function setSource($source): self
    {
        $this->source = $source;

        return $this;
    }

    /**
     * Get the value of featuredImage
     */
    public function getFeaturedImage()
    {
        return $this->featuredImage;
    }

    /**
     * Set the value of featuredImage
     */
    public function setFeaturedImage($featuredImage): self
    {
        $this->featuredImage = $featuredImage;

        return $this;
    }

    /**
     * Get the value of visibile
     */
    public function getVisibility()
    {
        return $this->visibile;
    }

    /**
     * Set the value of visibile
     */
    public function setVisibility($visibile): self
    {
        $this->visibile = $visibile;

        return $this;
    }

    // Methods
    private function createArticle( $data = [] )
    {
        // Create a new article
    }

    private function updateArticle( $id = 0, $data = [] )
    {
        // Update an existing article
    }

    private function deleteArticle( $id = 0 )
    {
        // Delete an existing article
    }

    private function getArticle( $id = 0 )
    {
        // Get an existing article
    }

    private function getArticles( $category = 'all' )
    {
        // Get all existing articles (by category or all)
    }
}
