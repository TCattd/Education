<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="hidden contact"></div>

    <!-- Main Article -->
    <main class="main container">
        <nav class="breadcrumb" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <h1>Contacto</h1>
                </li>
            </ol>
        </nav>

        <div class="row">
            <section class="article col-12 card p-5">
                <p>
                    <strong>El Faro</strong> es un periódico digital que se enfoca en la actualidad nacional e internacional.
                    Contamos con una amplia cobertura de noticias de deportes, negocios, política y más.
                </p>
                <hr>
                <p>
                    Escríbanos:
                </p>

                <!-- Because we can't use PHP in the assignment, we'll just use a mailto link instead -->
                <form id="contact" action="mailto:no-responder@aiepvirtual.cl" method="post" enctype="text/plain" class="container">
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Nombre</label>
                        <div class="col-sm-10">
                            <input class="input form-control" type="text" placeholder="Su nombre y apellido" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Asunto</label>
                        <div class="col-sm-10">
                            <input class="input form-control" type="text" placeholder="El asunto de contacto" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Correo</label>
                        <div class="col-sm-10">
                            <input class="input form-control" type="email" placeholder="Su correo electrónico" value="" required>
                        </div>
                        <!--<p class="help is-danger">Introduzca un email válido</p>-->
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Mensaje</label>
                        <div class="col-sm-10">
                            <textarea class="textarea form-control js-editor" placeholder="Escriba acá su mensaje" required></textarea>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12 send-form-container">
                            <button class="send-form btn btn-primary form-control">Enviar Correo</button>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    </main> <!-- / .main -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/esteban/Dev/Local/elfaro/app/public/resources/views/contact.blade.php ENDPATH**/ ?>